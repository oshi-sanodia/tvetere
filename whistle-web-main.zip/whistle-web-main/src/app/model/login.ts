export class Login {
    loginid :string;
    pwd:string;

}
