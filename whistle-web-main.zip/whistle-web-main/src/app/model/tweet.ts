export class Tweet {
    id:string;
    parentId:string;
    userid:string;
    message:string;
    postedAt:string;
    likes: number;
    /*id generated backend
    if id!=null parentid=id
    likes intially zero
    */
}
